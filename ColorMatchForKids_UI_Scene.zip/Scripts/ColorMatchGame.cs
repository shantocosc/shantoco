// ColorMatchGame.cs
// Unity C# Script for a simple kids color-matching game

using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ColorMatchGame : MonoBehaviour
{
    public Text questionText;
    public Button[] colorButtons;
    public Color[] colors;
    public string[] colorNames;

    private int correctIndex;

    void Start()
    {
        GenerateQuestion();
    }

    void GenerateQuestion()
    {
        correctIndex = Random.Range(0, colors.Length);
        questionText.text = "Tap on the color: " + colorNames[correctIndex];

        for (int i = 0; i < colorButtons.Length; i++)
        {
            int index = i; // local copy for closure
            colorButtons[i].GetComponent<Image>().color = colors[index];
            colorButtons[i].onClick.RemoveAllListeners();
            colorButtons[i].onClick.AddListener(() => CheckAnswer(index));
        }
    }

    void CheckAnswer(int selectedIndex)
    {
        if (selectedIndex == correctIndex)
        {
            questionText.text = "Great job! 🎉";
            Invoke("GenerateQuestion", 1.5f);
        }
        else
        {
            questionText.text = "Try again! 🙈";
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
